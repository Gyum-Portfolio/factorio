package com.besome.sketch.editor.manage.library.admob;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.v;

import com.besome.sketch.beans.ProjectLibraryBean;
import com.besome.sketch.editor.manage.library.ProjectComparator;
import com.besome.sketch.lib.base.BaseAppCompatActivity;
import com.besome.sketch.lib.ui.CircleImageView;
import com.sketchware.remod.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import a.a.a.GB;
import a.a.a.Iu;
import a.a.a.Ku;
import a.a.a.Nu;
import a.a.a.Tu;
import a.a.a.Uu;
import a.a.a.aB;
import a.a.a.bB;
import a.a.a.ci;
import a.a.a.iC;
import a.a.a.lC;
import a.a.a.mB;
import a.a.a.wB;
import a.a.a.wq;
import a.a.a.xB;
import a.a.a.yB;
import mod.hey.studios.util.Helper;

public class AdmobActivity extends BaseAppCompatActivity implements View.OnClickListener {
    private TextView nextStep;
    private ImageView back;
    private TextView stepTitle;
    private TextView stepDescription;
    private LinearLayout stepContainer;
    private String[] stepTitles;
    private String[] stepDescriptions;
    private int stepPosition = 0;
    private Uu step;
    private ProjectLibraryBean adMobSettings;
    private Button goToDocumentation;
    private Button importFromOtherProject;
    private ArrayList<HashMap<String, Object>> projects = new ArrayList<>();
    private ProjectsAdapter adapter;
    private String sc_id;
    private CardView goToConsole;
    private TextView previousStep;
    private TextView topTitle;

    private void f(int position) {
        if (position == 3) {
            topTitle.setText(Helper.getResString(R.string.common_word_review));
            nextStep.setText(Helper.getResString(R.string.common_word_save));
        } else {
            topTitle.setText(xB.b().a(this, R.string.common_word_step, position + 1));
            nextStep.setText(Helper.getResString(R.string.common_word_next));
        }

        if (position == 0) {
            back.setVisibility(View.VISIBLE);
            previousStep.setVisibility(View.GONE);
        } else {
            back.setVisibility(View.GONE);
            previousStep.setVisibility(View.VISIBLE);
        }

        stepTitle.setText(stepTitles[position]);
        stepDescription.setText(stepDescriptions[position]);
        stepContainer.removeAllViews();
        switch (position) {
            case 0:
                Iu setAdUnitItem = new Iu(this);
                stepContainer.addView(setAdUnitItem);
                setAdUnitItem.setData(adMobSettings);
                step = setAdUnitItem;
                break;

            case 1:
                goToConsole.setVisibility(View.GONE);
                Nu var4 = new Nu(this);
                stepContainer.addView(var4);
                var4.setData(adMobSettings);
                step = var4;
                break;

            case 2:
                goToConsole.setVisibility(View.GONE);
                Tu var3 = new Tu(this);
                stepContainer.addView(var3);
                var3.setData(adMobSettings);
                step = var3;
                break;

            case 3:
                goToConsole.setVisibility(View.GONE);
                Ku var2 = new Ku(this);
                stepContainer.addView(var2);
                var2.setData(adMobSettings);
                step = var2;
                break;
        }

        if (step.getDocUrl().isEmpty()) {
            goToDocumentation.setVisibility(View.GONE);
        } else {
            goToDocumentation.setVisibility(View.VISIBLE);
        }

        if (position > 0) {
            importFromOtherProject.setVisibility(View.GONE);
        } else {
            importFromOtherProject.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.ani_fade_in, R.anim.ani_fade_out);
    }

    private void m() {
        projects = new ArrayList<>();

        for (HashMap<String, Object> stringObjectHashMap : lC.a()) {
            String var3 = yB.c(stringObjectHashMap, "sc_id");
            if (!sc_id.equals(var3)) {
                iC var4 = new iC(var3);
                var4.i();
                if (var4.b().useYn.equals("Y")) {
                    stringObjectHashMap.put("admob_setting", var4.b().clone());
                    projects.add(stringObjectHashMap);
                }
            }
        }

        if (projects.size() > 0) {
            //noinspection Java8ListSort
            Collections.sort(projects, new ProjectComparator());
        }

        adapter.c();
    }

    private void n() {
        if (step.isValid()) {
            step.a(adMobSettings);
            int position = stepPosition;
            if (position < 3) {
                ++position;
                stepPosition = position;
                f(position);
            } else {
                Intent intent = new Intent();
                intent.putExtra("admob", adMobSettings);
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        int position = stepPosition;
        if (position > 0) {
            --position;
            stepPosition = position;
            f(position);
        } else {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    @Override
    public void onClick(View var1) {
        switch (var1.getId()) {
            case R.id.btn_open_doc:
                p();
                break;
            case R.id.cv_console:
                o();
                break;
            case R.id.tv_nextbtn:
                n();
                break;
            case R.id.tv_prevbtn:
                onBackPressed();
        }
    }

    private void o() {
        if (GB.h(this)) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse("https://apps.admob.com/v2/home"));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
                u();
            }
        } else {
            bB.a(this, Helper.getResString(R.string.common_message_check_network), 0).show();
        }
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.ani_fade_in, R.anim.ani_fade_out);
        setContentView(R.layout.manage_library_admob);
        if (savedInstanceState != null) {
            sc_id = savedInstanceState.getString("sc_id");
        } else {
            sc_id = getIntent().getStringExtra("sc_id");
        }

        stepTitles = new String[]{
                Helper.getResString(R.string.design_library_admob_setting_step1_title),
                Helper.getResString(R.string.design_library_admob_setting_step2_title),
                Helper.getResString(R.string.design_library_admob_setting_step3_title),
                Helper.getResString(R.string.design_library_admob_setting_step4_title)
        };
        stepDescriptions = new String[]{
                Helper.getResString(R.string.design_library_admob_setting_step1_desc),
                Helper.getResString(R.string.design_library_admob_setting_step2_desc),
                Helper.getResString(R.string.design_library_admob_setting_step3_desc),
                Helper.getResString(R.string.design_library_admob_setting_step4_desc)
        };
        goToConsole = findViewById(R.id.cv_console);
        goToConsole.setOnClickListener(this);
        TextView goToConsole = findViewById(R.id.tv_goto_console);
        goToConsole.setText(Helper.getResString(R.string.design_library_admob_button_goto_setting));
        previousStep = findViewById(R.id.tv_prevbtn);
        previousStep.setText(Helper.getResString(R.string.common_word_prev));
        previousStep.setOnClickListener(this);
        ImageView icon = findViewById(R.id.icon);
        icon.setImageResource(R.drawable.widget_admob);
        topTitle = findViewById(R.id.tv_toptitle);
        nextStep = findViewById(R.id.tv_nextbtn);
        nextStep.setText(Helper.getResString(R.string.common_word_next));
        nextStep.setOnClickListener(this);
        back = findViewById(R.id.img_backbtn);
        back.setOnClickListener(Helper.getBackPressedClickListener(this));
        stepTitle = findViewById(R.id.tv_step_title);
        stepDescription = findViewById(R.id.tv_step_desc);
        goToDocumentation = findViewById(R.id.btn_open_doc);
        goToDocumentation.setText(Helper.getResString(R.string.common_word_go_to_documentation));
        goToDocumentation.setOnClickListener(this);
        importFromOtherProject = findViewById(R.id.btn_import);
        importFromOtherProject.setText(Helper.getResString(R.string.design_library_button_import_from_other_project));
        importFromOtherProject.setOnClickListener(view -> s());
        stepContainer = findViewById(R.id.layout_container);
    }

    @Override
    public void onPostCreate(Bundle var1) {
        super.onPostCreate(var1);
        adMobSettings = getIntent().getParcelableExtra("admob");
        f(stepPosition);
    }

    @Override
    public void onSaveInstanceState(Bundle var1) {
        var1.putString("sc_id", sc_id);
        super.onSaveInstanceState(var1);
    }

    private void p() {
        if (!step.getDocUrl().isEmpty()) {
            if (GB.h(this)) {
                try {
                    Uri var1 = Uri.parse(step.getDocUrl());
                    Intent var2 = new Intent(Intent.ACTION_VIEW);
                    var2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    var2.setData(var1);
                    var2.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    var2.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    var2.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivity(var2);
                } catch (Exception var3) {
                    var3.printStackTrace();
                    u();
                }
            } else {
                bB.a(this, Helper.getResString(R.string.common_message_check_network), 0).show();
            }

        }
    }

    private void s() {
        aB dialog = new aB(this);
        dialog.b(Helper.getResString(R.string.design_library_title_select_project));
        dialog.a(R.drawable.widget_admob);
        View rootView = wB.a(this, R.layout.manage_library_popup_project_selector);
        RecyclerView recyclerView = rootView.findViewById(R.id.list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProjectsAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setItemAnimator(new ci());
        m();
        dialog.a(rootView);
        dialog.b(Helper.getResString(R.string.common_word_select), view -> {
            if (!mB.a()) {
                if (adapter.c >= 0) {
                    HashMap<String, Object> projectMap = projects.get(adapter.c);
                    adMobSettings = (ProjectLibraryBean) projectMap.get("admob_setting");
                    stepPosition = 3;
                    f(stepPosition);
                    dialog.dismiss();
                }
            }

        });
        dialog.a(Helper.getResString(R.string.common_word_cancel), Helper.getDialogDismissListener(dialog));
        dialog.show();
    }

    private void u() {
        aB dialog = new aB(this);
        dialog.a(R.drawable.chrome_96);
        dialog.b(Helper.getResString(R.string.title_compatible_chrome_browser));
        dialog.a(Helper.getResString(R.string.message_compatible_chrome_brower));
        dialog.b(Helper.getResString(R.string.common_word_ok), view -> {
            if (!mB.a()) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("market://details?id=com.android.chrome"));
                startActivity(intent);
                dialog.dismiss();
            }
        });
        dialog.a(Helper.getResString(R.string.common_word_cancel), Helper.getDialogDismissListener(dialog));
        dialog.show();
    }


    public class ProjectsAdapter extends RecyclerView.a<ProjectsAdapter.ViewHolder> {

        public int c;

        public ProjectsAdapter() {
            c = -1;
        }

        @Override
        public int a() {
            return projects.size();
        }

        @Override
        public void b(ViewHolder viewHolder, int position) {
            HashMap<String, Object> projectMap = projects.get(position);
            String var4 = yB.c(projectMap, "sc_id");
            String iconDir = wq.e() + File.separator + var4;
            viewHolder.u.setImageResource(R.drawable.default_icon);
            if (yB.a(projectMap, "custom_icon")) {
                Uri iconUri;
                if (VERSION.SDK_INT >= 24) {
                    iconUri = FileProvider.a(getApplicationContext(), getPackageName() + ".provider", new File(iconDir, "icon.png"));
                } else {
                    iconUri = Uri.fromFile(new File(iconDir, "icon.png"));
                }

                viewHolder.u.setImageURI(iconUri);
            }

            viewHolder.w.setText(yB.c(projectMap, "my_app_name"));
            viewHolder.v.setText(yB.c(projectMap, "my_ws_name"));
            viewHolder.x.setText(yB.c(projectMap, "my_sc_pkg_name"));
            var4 = String.format("%s(%s)", yB.c(projectMap, "sc_ver_name"), yB.c(projectMap, "sc_ver_code"));
            viewHolder.y.setText(var4);

            viewHolder.z.setVisibility(yB.a(projectMap, "selected") ? View.VISIBLE : View.GONE);
        }

        @Override
        public ViewHolder b(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.manage_library_popup_project_list_item, parent, false));
        }

        public class ViewHolder extends v implements View.OnClickListener {

            public LinearLayout t;
            public CircleImageView u;
            public TextView v;
            public TextView w;
            public TextView x;
            public TextView y;
            public ImageView z;

            public ViewHolder(View itemView) {
                super(itemView);
                t = itemView.findViewById(R.id.project_layout);
                v = itemView.findViewById(R.id.project_name);
                u = itemView.findViewById(R.id.img_icon);
                w = itemView.findViewById(R.id.app_name);
                x = itemView.findViewById(R.id.package_name);
                y = itemView.findViewById(R.id.project_version);
                z = itemView.findViewById(R.id.img_selected);
                t.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {
                if (!mB.a() && view.getId() == R.id.project_layout) {
                    ProjectsAdapter.this.c = ProjectsAdapter.ViewHolder.this.j();
                    c(ProjectsAdapter.this.c);
                }
            }

            private void c(int index) {
                if (projects.size() > 0) {

                    for (HashMap<String, Object> stringObjectHashMap : projects) {
                        stringObjectHashMap.put("selected", false);
                    }

                    projects.get(index).put("selected", true);
                    adapter.c();
                }
            }
        }
    }

}
